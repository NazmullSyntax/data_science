
total = 0
for i in range(2, 101, 2):  
    total += i

print("Sum of even numbers between 1 and 100 is:", total)
